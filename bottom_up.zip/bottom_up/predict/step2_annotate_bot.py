import pandas as pd
import spacy
from collections import Counter
from tqdm import tqdm

# Load spaCy
nlp = spacy.load("en_core_web_sm")

# Define AI-related terms (lemmas)
ai_terms = {
    "ai", "chatgpt", "genai", "artificial intelligence",
    "machine", "llm", "deep learning", "machine learning",
    "natural language processing", "generativeai"
}

# Load predicted metaphor data
df = pd.read_csv("predict1.csv")
texts = df[df["predict1"] == 1]["sentence"].dropna().tolist()

# Storage for extracted verbs or related lemmas
used_verbs_for_ai = []

# Process each sentence
for doc in tqdm(nlp.pipe(texts, batch_size=50, disable=["ner"]), total=len(texts)):
    for token in doc:
        token_text = token.text.lower()
        token_lemma = token.lemma_.lower()
        head = token.head

        # Case 1: Token is AI term and it's a subject
        if token_lemma in ai_terms and token.dep_ == "nsubj":
            if head.pos_ in {"VERB", "AUX", "ADJ"}:
                used_verbs_for_ai.append(head.lemma_.lower())

        # Case 2: Token is verb and its subject is AI
        if token.pos_ in {"VERB", "AUX"}:
            for child in token.children:
                if child.dep_ == "nsubj" and child.lemma_.lower() in ai_terms:
                    used_verbs_for_ai.append(token.lemma_.lower())

# Count and display frequency
verb_freq = Counter(used_verbs_for_ai)
verb_df = pd.DataFrame(verb_freq.items(), columns=["verb_lemma", "frequency"]).sort_values(by="frequency", ascending=False)

# Output top results
print("\nTop verbs or lemmas used for AI-related subjects (in metaphor predictions):\n")
print(verb_df.head(20))

# Optional: save to file
verb_df.to_csv("ai_related_bottomup_verbs.csv", index=False)
